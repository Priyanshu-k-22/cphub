import React from "react";
import { Link } from "react-router-dom";

const problems = [
    {
        category: "CP",
        title: "Domino piling",
        meta: "Codeforces · 800",
    },
    {
        category: "DSA",
        title: "Maximum Subarray",
        meta: "LeetCode · Medium",
    },
];

const TodayProblems = () => {
    return (
        <div className="rounded-xl border border-[#1C2734] bg-[#0A1018] p-4">

            <div className="flex items-center justify-between">

                <h2 className="text-sm font-semibold">
                    Today's Problems
                </h2>

                <Link
                    to="/problems"
                    className="font-mono text-[10px] text-[#4AFFC4] hover:text-white"
                >
                    all →
                </Link>

            </div>


            <div className="mt-3 divide-y divide-[#1C2734]">

                {problems.map((problem) => (
                    <Link
                        key={problem.category}
                        to="/problems"
                        className="group flex items-center gap-3 py-2.5"
                    >

                        <span className="w-9 shrink-0 font-mono text-[9px] uppercase text-[#4AFFC4]">
                            {problem.category}
                        </span>

                        <div className="min-w-0 flex-1">

                            <p className="truncate text-xs font-medium transition group-hover:text-[#4AFFC4]">
                                {problem.title}
                            </p>

                            <p className="mt-0.5 font-mono text-[9px] text-[#556275]">
                                {problem.meta}
                            </p>

                        </div>

                        <span className="font-mono text-[10px] text-[#556275] transition group-hover:translate-x-1 group-hover:text-[#4AFFC4]">
                            →
                        </span>

                    </Link>
                ))}

            </div>

        </div>
    );
};

export default TodayProblems;