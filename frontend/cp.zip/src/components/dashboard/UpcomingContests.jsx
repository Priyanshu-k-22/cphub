import React from "react";
import { Link } from "react-router-dom";

const contests = [
    ["Codeforces Round", "Tomorrow · 18:35"],
    ["AtCoder Beginner Contest", "Saturday · 19:30"],
    ["CodeChef Starters", "Monday · 20:00"],
];

const UpcomingContests = () => {
    return (
        <div className="rounded-xl border border-[#1C2734] bg-[#0A1018] p-4">

            <div className="flex items-center justify-between">

                <h2 className="text-sm font-semibold">
                    Upcoming Contests
                </h2>

                <Link
                    to="/contests"
                    className="font-mono text-[9px] text-[#4AFFC4] hover:text-white"
                >
                    all →
                </Link>

            </div>


            <div className="mt-2 divide-y divide-[#1C2734]">

                {contests.map(([name, time]) => (
                    <div
                        key={name}
                        className="flex items-center justify-between gap-3 py-2.5"
                    >

                        <p className="truncate text-xs text-[#AEB9C7]">
                            {name}
                        </p>

                        <p className="shrink-0 font-mono text-[9px] text-[#556275]">
                            {time}
                        </p>

                    </div>
                ))}

            </div>

        </div>
    );
};

export default UpcomingContests;